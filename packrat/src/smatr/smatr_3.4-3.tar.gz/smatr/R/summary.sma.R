summary.sma <- function(object,...){
	print.sma(object, coefbygroup=TRUE)
}

