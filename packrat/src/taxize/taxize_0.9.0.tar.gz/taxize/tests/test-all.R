library(testthat)
library("taxize")
test_check("taxize")
