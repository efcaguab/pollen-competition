package org.rosuda.deducer.widgets.param;

public class ParamTextFieldLongWidget extends ParamTextFieldWidget {
	
	public ParamTextFieldLongWidget(Param p){
		super(p);
	}
	
}
