package org.rosuda.deducer.models;

public class RModel {
	public String formula;
	public String data;
	public String modelName;
	public String call;
	public String preview;
}
