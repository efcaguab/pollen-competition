package org.rosuda.deducer.data;

public interface DataViewerTabFactory {

	public DataViewerTab makeViewerTab(String dataName);
	
}
