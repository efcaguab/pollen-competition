package org.rosuda.deducer.widgets.param;

import javax.swing.JPanel;


public abstract class RFunctionView extends ParamWidget{
	
	public abstract void setModel(RFunction el);
	public abstract void updateModel();
}
