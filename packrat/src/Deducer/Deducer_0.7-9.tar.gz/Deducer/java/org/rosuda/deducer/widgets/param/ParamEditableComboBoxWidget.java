package org.rosuda.deducer.widgets.param;

public class ParamEditableComboBoxWidget extends ParamComboBoxWidget{
	public ParamEditableComboBoxWidget(Param p){
		super(p);
	}
}
