library("testthat")
library("tibble")
library("snakecase")
library("magrittr")


test_check("snakecase")