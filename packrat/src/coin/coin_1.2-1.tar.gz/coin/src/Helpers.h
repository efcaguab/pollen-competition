int nrow(SEXP x);
int ncol(SEXP x);
