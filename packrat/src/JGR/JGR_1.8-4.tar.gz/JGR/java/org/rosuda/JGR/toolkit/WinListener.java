package org.rosuda.JGR.toolkit;


import java.awt.event.WindowEvent;


public class WinListener extends org.rosuda.ibase.toolkit.WinListener {
    public WinListener() {
    }

    public void windowClosing(WindowEvent e) {
    }

}