#' @rdname prediction
#' @export
prediction.rlm <- prediction.default
